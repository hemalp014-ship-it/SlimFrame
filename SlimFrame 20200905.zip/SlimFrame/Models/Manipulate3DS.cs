﻿
using SlimDX;
using System.IO;
using System.Collections.Generic;

using static System.Math;
using static System.Diagnostics.Debug;
using System;
using System.Runtime.Remoting.Channels;

namespace SlimFrame.Models
{
    /// <summary>
    /// Manipulates 3DS Model for our model system.
    /// </summary>
    class Manipulate3DS
    {
        #region Constants

        const ushort MainID                      = 0x4d4d;
        const ushort M3DVersionID                = 0x0002;
        const ushort EditorID                    = 0x3d3d;
        const ushort ObjectBlockID               = 0x4000;
        const ushort TriangularMeshID            = 0x4100;
        const ushort VerticesListID              = 0x4110;
        const ushort FacesDescriptionID          = 0x4120;
        const ushort FacesMaterialID             = 0x4130;
        const ushort SmoothingGroupListID        = 0x4150;
        const ushort MappingCoordinatesListID    = 0x4140;
        const ushort LocalCoordinatesSystemID    = 0x4160;
        const ushort LightID                     = 0x4600;
        const ushort SpotlightID                 = 0x4610;
        const ushort CameraID                    = 0x4700;
        const ushort MaterialBlockID             = 0xAFFF;
        const ushort MaterialNameID              = 0xA000;
        const ushort AmbientColorID              = 0xA010;
        const ushort DiffuseColorID              = 0xA020;
        const ushort SpecularColorID             = 0xA030;
        const ushort TextureMapID                = 0xA200;
        const ushort BumpMapID                   = 0xA230;
        const ushort ReflectionMapID             = 0xA220;
        const ushort MappingFilenameID           = 0xA300;
        const ushort MappingParaemtersID         = 0xA351;
        const ushort KeyframerID                 = 0xB000;
        const ushort MeshInformationBlockID      = 0xB002;
        const ushort SpotLightInformationBlockID = 0xB007;
        const ushort FramesID                    = 0xB008;
        const ushort ObjectNameID                = 0xB010;
        const ushort ObjectPivotPointID          = 0xB013;
        const ushort PositionTrackID             = 0xB020;
        const ushort RotationTrackID             = 0xB021;
        const ushort ScaleTrackID                = 0xB022;
        const ushort HierarchyPositionID         = 0xB030;

        const int ColorRGB                      = 0x10;
        const int ColorTrue                     = 0x11;


        #endregion

        #region Structures

        struct Chunk
        {
            public ushort ID;
            public long length;
            public long start;
            public long end;

            public static Chunk Parse(BinaryReader reader)
            {
                Chunk chunk = new Chunk();
                chunk.start = reader.BaseStream.Position;
                chunk.ID = reader.ReadUInt16();
                chunk.length = reader.ReadInt32();
                chunk.end = chunk.start + chunk.length;

                return chunk;
            }
        }

        #endregion

        /// <summary>
        /// Loads a 3DS model to our model system.
        /// </summary>
        /// <param name="device">D3D 11 device</param>
        /// <param name="filepath">Path to the model</param>
        /// <param name="isRHCoordSys">Whether model is in right-handed coordinate system or not</param>
        /// <param name="computeNormals">Whether normals to be calculated or not</param>
        /// <param name="Debug">Whether the loading be done in Debug mode or not</param>
        /// <returns>A model loaded from 3DS model file</returns>
        public static Model Load(SlimDX.Direct3D11.Device device, string filepath, bool isRHCoordSys = false, bool computeNormals = false, bool Debug = false)
        {
            Model model = new Model(); // Model Object to which the file to be loaded
            string folder = filepath.Substring(0, filepath.LastIndexOf("\\") + 1); //path to folder where the model file resides

            List<uint> indices = new List<uint>(); // List of indices to vertex in each triangle
            List<Vector3> vertPos = new List<Vector3>(); // List of vertex position
            List<Vector3> vertNorm = new List<Vector3>(); // List of vertex normal
            List<Vector2> vertTex = new List<Vector2>(); // List of vertex texture co-ordinate
            List<string> meshMaterials = new List<string>();// List of mesh materials
            List<MaterialBase> material = new List<MaterialBase>();// List of mesh materials

            List<int> meshSubsetMaterial = new List<int>();
            List<int> meshSubsetIndexStart = new List<int>();
            List<string> meshSubsetNames = new List<string>();


            if (Debug) System.Diagnostics.Debug.WriteLine(filepath);

            FileStream file = new FileStream(filepath, FileMode.Open); //File stream to the file on which reader will work
            BinaryReader reader = new BinaryReader(file); //Binary reader for file

            Chunk mainchunk ;
            Chunk VersionChunk;

            mainchunk = Chunk.Parse(reader);

            if (mainchunk.ID != MainID)
            {
                if (Debug) System.Diagnostics.Debug.WriteLine(filepath + " model is corrupted!");
                return null;
            }

            VersionChunk = Chunk.Parse(reader);
            if (reader.ReadInt32() < 3)
            {
                if (Debug) System.Diagnostics.Debug.WriteLine("Loader can only read 3ds file having version greater than 3!");
                return null;
            }

            Chunk chunk = new Chunk();
            do
            {
                chunk = Chunk.Parse(reader);
                switch (chunk.ID)
                {
                    case EditorID:
                        readEditorData(chunk,reader);
                        break;
                    case KeyframerID:
                        readKeyframeData(chunk, reader);
                        break;
                    default:
                        break;
                }
            } while (reader.BaseStream.Position < mainchunk.end);

            reader.Dispose();
            file.Dispose();

            if (Debug) System.Diagnostics.Debug.WriteLine(filepath + " model is loaded!");
            return model;
        }

        private static void readEditorData(Chunk Editor,BinaryReader reader)
        {
            Chunk chunk = new Chunk();
            do
            {
                switch (chunk.ID)
                {
                    case ObjectBlockID:
                        readObjectData(chunk,reader);
                        break;
                    case MaterialBlockID:
                        readMaterialData(chunk,reader);
                        break;
                    default:
                        break;
                }
            } while (reader.BaseStream.Position < Editor.end);
        }
        private static void readObjectData(Chunk SpatialObject,BinaryReader reader)
        {
            string name = reader.ReadString();
            Chunk chunk = new Chunk();
            do
            {
                chunk = Chunk.Parse(reader);
                switch (chunk.ID)
                {
                    case TriangularMeshID:
                        readTriangularMeshData(chunk,reader);
                        break;
                    case LightID:
                        readLightData(chunk, reader);
                        break;
                    case CameraID:
                        readCameraData(chunk, reader);
                        break;
                    default:
                        break;
                }
            } while (reader.BaseStream.Position < SpatialObject.end);
        }
        private static ObjectBase readTriangularMeshData(Chunk Triangularmesh,BinaryReader reader)
        {
            ObjectBase objectBase = new ObjectBase();
            Vector3[] Positions = new Vector3[] { };
            Vector3[] Normals = new Vector3[] { };
            Vector2[] Texcoords = new Vector2[] { };

            string name = reader.ReadString();
            Chunk chunk = new Chunk();
            do
            {
                chunk = Chunk.Parse(reader);
                switch (chunk.ID)
                {
                    case VerticesListID:
                        Positions = readVerticesList(chunk, reader);
                        break;
                    case FacesDescriptionID:
                        readFaceDescription(chunk, reader);
                        break;
                    case MappingCoordinatesListID:
                        Texcoords = readMappingCoordinatesList(chunk, reader);
                        break;
                    case LocalCoordinatesSystemID:
                        readLocalCoordinatesSystem(chunk, reader);
                        break;
                    default:
                        break;
                }
            } while (reader.BaseStream.Position < Triangularmesh.end);

            return objectBase;
        }
        private static void readLocalCoordinatesSystem(Chunk chunk, BinaryReader reader)
        {

        }
        private static Vector2[] readMappingCoordinatesList(Chunk chunk, BinaryReader reader)
        {
            List<Vector2> texCoords = new List<Vector2>();

            return texCoords.ToArray();
        }
        private static void readFaceDescription(Chunk chunk, BinaryReader reader)
        {
            //TODO: First read the face as this way: read integer, say it as faces count and read faces,
            //      which having four component in a integer list, but store only first three
            //      And then read face material chunk and smoothing group chunk
        }
        private static Vector3[] readVerticesList(Chunk chunk, BinaryReader reader)
        {
            int verticeCount = reader.ReadInt32();
            List<Vector3> vertices = new List<Vector3>();

            for (int i = 0; i < verticeCount; i++)
            {
                vertices.Add(new Vector3(reader.ReadSingle(), reader.ReadSingle(), reader.ReadSingle()));
            }

            return vertices.ToArray();
        }
        private static void readLightData(Chunk Light,BinaryReader reader)
        {
             //TODO: First read Light Data and then read SpotLight chunk, if any
        }
        private static void readCameraData(Chunk Light,BinaryReader reader)
        {

        }
        private static void readMaterialData(Chunk Material,BinaryReader reader)
        {
            MaterialBase mat = new MaterialBase();
            Chunk chunk = new Chunk();
            do
            {
                switch (chunk.ID)
                {
                    case MaterialNameID:
                        mat.Name = reader.ReadString();
                        break;
                    case AmbientColorID:
                        mat.Ambient = readColorChunk(reader);
                        break;
                    case DiffuseColorID:
                        mat.Diffuse = readColorChunk(reader);
                        break;
                    case SpecularColorID:
                        mat.Specular = readColorChunk(reader);
                        break;
                    case TextureMapID:
                        mat.Texture = readTexture(chunk,reader);
                        mat.TextureType = TextureType.texture2D;
                        break;
                    case BumpMapID:
                        mat.BumpMap = readTexture(chunk,reader);
                        mat.BumpType = TextureType.texture2D;
                        break;
                    case ReflectionMapID:
                        mat.BumpMap = readTexture(chunk,reader);
                        mat.BumpType = TextureType.texture2D;
                        break;
                    default:
                        break;
                }
            } while (reader.BaseStream.Position < Material.end);
        }
        private static string readTexture(Chunk Texture,BinaryReader reader)
        {
            string name = "tex.0000";
            Chunk chunk = new Chunk();
            do
            {
                switch (chunk.ID)
                {
                    case MappingFilenameID:
                        name = reader.ReadString();
                        break;
                    case MappingParaemtersID:
                        readMaterialData(chunk, reader);
                        break;
                    default:
                        break;
                }
            } while (reader.BaseStream.Position < Texture.end);
            return name;
        }
        private static Color4 readColorChunk(BinaryReader reader)
        {
            Color4 color = new Color4();
            int type = reader.ReadInt32();
            switch (type)
            {
                case ColorRGB:
                    color = readColorRGB(reader);
                    break;
                case ColorTrue:
                    color = readColorTrue(reader);
                    break;
            }
            return color;
        }
        private static Color4 readColorRGB(BinaryReader reader)
        {
            return new Color4()
            {
                Red = reader.ReadSingle(),
                Green = reader.ReadSingle(),
                Blue = reader.ReadSingle(),
                Alpha = 1
            };
        }
        private static Color4 readColorTrue(BinaryReader reader)
        {
            return new Color4()
            {
                Red = (float) reader.ReadByte() / 255,
                Green = (float) reader.ReadByte() / 255,
                Blue = (float) reader.ReadByte() / 255,
                Alpha = 1
            };
        }
        private static void readKeyframeData(Chunk KeyFrame,BinaryReader reader)
        {
            Chunk chunk = new Chunk();
            do
            {
                switch (chunk.ID)
                {
                    case MeshInformationBlockID:
                        readMeshInformationBlock(chunk, reader);
                        break;
                    case SpotLightInformationBlockID:
                        readSpotLightInformationBlock(chunk,reader);
                        break;
                    case FramesID:
                        readFramesData(chunk, reader);
                        break;
                    default:
                        break;
                }
            } while (reader.BaseStream.Position < KeyFrame.end);
        }
        private static void readMeshInformationBlock(Chunk chunk, BinaryReader reader)
        {

        }
        private static void readSpotLightInformationBlock(Chunk chunk, BinaryReader reader)
        {

        }
        private static void readFramesData(Chunk FramesChunk, BinaryReader reader)
        {
            string name;
            Chunk chunk = new Chunk();
            do
            {
                switch (chunk.ID)
                {
                    case ObjectNameID:
                        name = reader.ReadString();
                        break;
                    case ObjectPivotPointID:
                        readObjectPivotPoint(chunk, reader);
                        break;
                    case PositionTrackID:
                        readPositionTrackData(chunk, reader);
                        break;
                    case RotationTrackID:
                        readRotationTrackData(chunk, reader);
                        break;
                    case ScaleTrackID:
                        readScaleTrackData(chunk, reader);
                        break;
                    case HierarchyPositionID:
                        readHierarchyPosition(chunk, reader);
                        break;
                    default:
                        break;
                }
            } while (reader.BaseStream.Position < FramesChunk.end);
        }
        private static void readObjectPivotPoint(Chunk chunk, BinaryReader reader)
        {

        }
        private static void readPositionTrackData(Chunk chunk, BinaryReader reader)
        {

        }
        private static void readRotationTrackData(Chunk chunk, BinaryReader reader)
        {

        }
        private static void readScaleTrackData(Chunk chunk, BinaryReader reader)
        {

        }
        private static void readHierarchyPosition(Chunk chunk, BinaryReader reader)
        {

        }
    }
}
