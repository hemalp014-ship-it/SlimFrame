﻿using SlimDX;
using SlimDX.Direct3D11;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;

namespace SlimFrame.Models
{
	public class Object3D : IDisposable
	{
		public Matrix Tranformation;

		private bool disposedValue = false;

		public int VertexCount
		{
			get;
			protected set;
		}

		public int IndexCount
		{
			get;
			protected set;
		}

		public SlimDX.Direct3D11.Buffer VertexBuffer
		{
			get;
			protected set;
		}

		public SlimDX.Direct3D11.Buffer IndexBuffer
		{
			get;
			protected set;
		}

		public List<int> Subsets
		{
			get;
			protected set;
		}

		public int SubsetCount
		{
			get;
			protected set;
		}

		public List<int> MaterialIDs
		{
			get;
			protected set;
		}

		public VertexBufferBinding vertexBufferBinding
		{
			get;
			protected set;
		}

		public List<string> SubsetNames
		{
			get;
			protected set;
		}

		public Object3D()
		{
		}

		public Object3D(Device dev, Vertex[] vertices, uint[] indices, int[] Materials, int[] meshSubsets, string[] meshSubsetNames, bool Debug = false)
		{
			this.IndexCount = indices.Length;
			this.VertexCount = vertices.Length;
			this.MaterialIDs = new List<int>();
			this.Subsets = new List<int>();
			this.SubsetNames = new List<string>();

			DataStream dataStream = new DataStream((long)(Vertex.Size * vertices.Length), true, true);
			for (int i = 0; i < vertices.Length; i++)
			{
				Vertex value = vertices[i];
				dataStream.Write<Vertex>(value);
			}
			dataStream.Position = 0L;
			this.VertexBuffer = new SlimDX.Direct3D11.Buffer(dev, dataStream, new BufferDescription
			{
				Usage = ResourceUsage.Default,
				SizeInBytes = Vertex.Size * vertices.Length,
				BindFlags = BindFlags.VertexBuffer,
				CpuAccessFlags = CpuAccessFlags.None,
				OptionFlags = ResourceOptionFlags.None,
				StructureByteStride = Vertex.Size
			});
			dataStream.Dispose();
			dataStream = new DataStream((long)(4 * indices.Length), true, true);
			for (int j = 0; j < indices.Length; j++)
			{
				int value2 = (int)indices[j];
				dataStream.Write<int>(value2);
			}
			dataStream.Position = 0L;
			this.IndexBuffer = new SlimDX.Direct3D11.Buffer(dev, dataStream, new BufferDescription
			{
				Usage = ResourceUsage.Default,
				SizeInBytes = 4 * indices.Length,
				BindFlags = BindFlags.IndexBuffer,
				CpuAccessFlags = CpuAccessFlags.None,
				OptionFlags = ResourceOptionFlags.None,
				StructureByteStride = 4
			});
			this.vertexBufferBinding = new VertexBufferBinding(this.VertexBuffer, Vertex.Size, 0);
			if (Debug)
			{
				System.Diagnostics.Debug.WriteLine("mat count :- " + Materials.Length.ToString());
			}
			for (int k = 0; k < Materials.Length; k++)
			{
				int item = Materials[k];
				this.MaterialIDs.Add(item);
				if (Debug)
				{
					System.Diagnostics.Debug.WriteLine("mat id :- " + item.ToString());
				}
			}
			if (Debug)
			{
				System.Diagnostics.Debug.WriteLine("sub count :- " + (meshSubsets.Length - 1).ToString());
			}
			for (int l = 0; l < meshSubsets.Length; l++)
			{
				int item2 = meshSubsets[l];
				bool flag = !this.Subsets.Contains(item2);
				if (flag)
				{
					this.Subsets.Add(item2);
				}
			}
			bool flag2 = meshSubsetNames != null;
			if (flag2)
			{
				for (int m = 0; m < meshSubsetNames.Length; m++)
				{
					string item3 = meshSubsetNames[m];
					this.SubsetNames.Add(item3);
				}
			}
			this.SubsetCount = meshSubsets.Length - 1;
			this.Tranformation = Matrix.Scaling(1f, 1f, 1f);
		}

		public Object3D(Device dev, ObjectBase model, bool Debug = false)
		{
			this.IndexCount = model.indices.Length;
			this.VertexCount = model.vertices.Length;
			this.MaterialIDs = new List<int>();
			this.Subsets = new List<int>();
			DataStream dataStream = new DataStream((long)(Vertex.Size * model.vertices.Length), true, true);
			Vertex[] vertices = model.vertices;
			for (int i = 0; i < vertices.Length; i++)
			{
				Vertex value = vertices[i];
				dataStream.Write<Vertex>(value);
			}
			dataStream.Position = 0L;
			this.VertexBuffer = new SlimDX.Direct3D11.Buffer(dev, dataStream, new BufferDescription
			{
				Usage = ResourceUsage.Default,
				SizeInBytes = Vertex.Size * model.vertices.Length,
				BindFlags = BindFlags.VertexBuffer,
				CpuAccessFlags = CpuAccessFlags.None,
				OptionFlags = ResourceOptionFlags.None,
				StructureByteStride = Vertex.Size
			});
			dataStream.Dispose();
			dataStream = new DataStream((long)(4 * model.indices.Length), true, true);
			uint[] indices = model.indices;
			for (int j = 0; j < indices.Length; j++)
			{
				int value2 = (int)indices[j];
				dataStream.Write<int>(value2);
			}
			dataStream.Position = 0L;
			this.IndexBuffer = new SlimDX.Direct3D11.Buffer(dev, dataStream, new BufferDescription
			{
				Usage = ResourceUsage.Default,
				SizeInBytes = 4 * model.indices.Length,
				BindFlags = BindFlags.IndexBuffer,
				CpuAccessFlags = CpuAccessFlags.None,
				OptionFlags = ResourceOptionFlags.None,
				StructureByteStride = 4
			});
			this.vertexBufferBinding = new VertexBufferBinding(this.VertexBuffer, Vertex.Size, 0);
			this.Tranformation = model.Tranformation;
			if (Debug)
			{
				System.Diagnostics.Debug.WriteLine("mat count :- " + model.MaterialIDs.Count.ToString());
			}
			foreach (int current in model.MaterialIDs)
			{
				this.MaterialIDs.Add(current);
				if (Debug)
				{
					System.Diagnostics.Debug.WriteLine("mat id :- " + current.ToString());
				}
			}
			if (Debug)
			{
				System.Diagnostics.Debug.WriteLine("sub count :- " + (model.meshSubsets.Count - 1).ToString());
			}
			foreach (int current2 in model.meshSubsets)
			{
				this.Subsets.Add(current2);
				if (Debug)
				{
					System.Diagnostics.Debug.WriteLine("sub index :- " + current2.ToString());
				}
			}
			this.SubsetCount = this.Subsets.Count - 1;
			this.Tranformation = Matrix.Scaling(1f, 1f, 1f);
		}

		public void Draw(DeviceContext devCon, int startIndexLocation = 0, int baseVertexLocation = 0)
		{
			devCon.DrawIndexed(this.IndexCount, 0, 0);
		}

		public void DrawSubset(DeviceContext devCon, int subset)
		{
			devCon.DrawIndexed(this.Subsets[subset + 1] - this.Subsets[subset], this.Subsets[subset], 0);
		}

		public void DrawInstanced(DeviceContext devCon, int instanceCount, int startIndexLocation = 0, int baseVertexLocation = 0, int startInstanceLocation = 0)
		{
			devCon.DrawIndexedInstanced(this.IndexCount, instanceCount, startIndexLocation, baseVertexLocation, startInstanceLocation);
		}

		public void DrawInstancedSubset(DeviceContext devCon, int subset, int instanceCount, int baseVertexLocation = 0, int startInstanceLocation = 0)
		{
			devCon.DrawIndexedInstanced(this.Subsets[subset + 1] - this.Subsets[subset], instanceCount, this.Subsets[subset], baseVertexLocation, startInstanceLocation);
		}

		public void Write(DeviceContext devCon, BinaryWriter writer)
		{
			Object3D.Write(devCon, writer, this);
		}

		public void Read(Device device, BinaryReader reader, long ChunkEnding)
		{
			Object3D.Read(this, device, reader, ChunkEnding);
		}

		public static Object3D FromStream(Device device, BinaryReader reader, long ChunkEnding)
		{
			Object3D object3D = new Object3D();
			Object3D.Read(object3D, device, reader, ChunkEnding);
			return object3D;
		}

		public static void Read(Object3D obj, Device device, BinaryReader reader, long ChunkEnding)
		{
			obj.Subsets = new List<int>();
			Chunk chunk = default(Chunk);
			obj.MaterialIDs = new List<int>();
			obj.Subsets = new List<int>();
			while (true)
			{
				chunk.Read(reader);
				switch (chunk.id)
				{
					case 45057:
						{
							int num = reader.ReadInt32();
							DataStream dataStream = new DataStream((long)(Vertex.Size * num), true, true);
							for (int i = 0; i < num; i++)
							{
								dataStream.Write<Vertex>(Vertex.Read(reader));
							}
							dataStream.Position = 0L;
							obj.VertexBuffer = new SlimDX.Direct3D11.Buffer(device, dataStream, new BufferDescription
							{
								Usage = ResourceUsage.Default,
								SizeInBytes = Vertex.Size * num,
								BindFlags = BindFlags.VertexBuffer,
								CpuAccessFlags = CpuAccessFlags.None,
								OptionFlags = ResourceOptionFlags.None,
								StructureByteStride = Vertex.Size
							});
							obj.vertexBufferBinding = new VertexBufferBinding(obj.VertexBuffer, Vertex.Size, 0);
							dataStream.Dispose();
							obj.VertexCount = num;
							break;
						}
					case 45058:
						{
							int num2 = reader.ReadInt32();
							DataStream dataStream = new DataStream((long)(4 * num2), true, true);
							for (int j = 0; j < num2; j++)
							{
								dataStream.Write<uint>(reader.ReadUInt32());
							}
							dataStream.Position = 0L;
							obj.IndexBuffer = new SlimDX.Direct3D11.Buffer(device, dataStream, new BufferDescription
							{
								Usage = ResourceUsage.Default,
								SizeInBytes = 4 * num2,
								BindFlags = BindFlags.IndexBuffer,
								CpuAccessFlags = CpuAccessFlags.None,
								OptionFlags = ResourceOptionFlags.None,
								StructureByteStride = 4
							});
							dataStream.Dispose();
							obj.IndexCount = num2;
							break;
						}
					case 45059:
						{
							int num3 = reader.ReadInt32();
							for (int k = 0; k < num3; k++)
							{
								obj.MaterialIDs.Add(reader.ReadInt32());
							}
							break;
						}
					case 45060:
						{
							int num4 = reader.ReadInt32();
							for (int l = 0; l < num4; l++)
							{
								obj.Subsets.Add(reader.ReadInt32());
							}
							break;
						}
					case 45061:
						goto IL_253;
					case 45062:
						Object3D.ReadMatrix(reader, ref obj.Tranformation);
						break;
					default:
						goto IL_253;
				}
				IL_269:
				if (reader.BaseStream.Position + 6L >= ChunkEnding)
				{
					break;
				}
				continue;
				IL_253:
				reader.BaseStream.Seek(chunk.End, SeekOrigin.Begin);
				goto IL_269;
			}
			obj.SubsetCount = obj.Subsets.Count - 1;
		}

		public unsafe static void Write(DeviceContext devCon, BinaryWriter writer, Object3D obj)
		{
			List<int> list = new List<int>();
			List<int> list2 = new List<int>();
			writer.Write(45056);
			list.Add((int)writer.BaseStream.Position);
			writer.Write(0);
			writer.Write(45057);
			list.Add((int)writer.BaseStream.Position);
			writer.Write(0);
			writer.Write(obj.VertexCount);
			BufferDescription description = default(BufferDescription);
			description.Usage = ResourceUsage.Dynamic;
			description.SizeInBytes = Vertex.Size * obj.VertexCount;
			description.BindFlags = BindFlags.VertexBuffer;
			description.CpuAccessFlags = CpuAccessFlags.Write;
			description.OptionFlags = ResourceOptionFlags.None;
			description.StructureByteStride = Vertex.Size;
			DataStream dataStream = new DataStream((long)(Vertex.Size * obj.VertexCount), true, true);
			SlimDX.Direct3D11.Buffer buffer = new SlimDX.Direct3D11.Buffer(devCon.Device, dataStream, description);
			devCon.CopyResource(obj.VertexBuffer, buffer);
			DataBox dataBox = devCon.MapSubresource(buffer, MapMode.WriteNoOverwrite, MapFlags.None);
			Vertex* ptr = (Vertex*)((void*)dataBox.Data.DataPointer);
			for (int i = 0; i < obj.VertexCount; i++)
			{
				Vertex vertex = ptr[i];
				vertex.Write(writer);
			}
			devCon.UnmapSubresource(buffer, 0);
			dataStream.Dispose();
			buffer.Dispose();
			dataBox.Data.Dispose();
			list2.Add((int)writer.BaseStream.Position);
			writer.Write(45058);
			list.Add((int)writer.BaseStream.Position);
			writer.Write(0);
			writer.Write(obj.IndexCount);
			description = default(BufferDescription);
			description.Usage = ResourceUsage.Dynamic;
			description.SizeInBytes = 4 * obj.IndexCount;
			description.BindFlags = BindFlags.IndexBuffer;
			description.CpuAccessFlags = CpuAccessFlags.Write;
			description.OptionFlags = ResourceOptionFlags.None;
			description.StructureByteStride = 4;
			dataStream = new DataStream((long)(4 * obj.IndexCount), true, true);
			SlimDX.Direct3D11.Buffer buffer2 = new SlimDX.Direct3D11.Buffer(devCon.Device, dataStream, description);
			devCon.CopyResource(obj.IndexBuffer, buffer2);
			dataBox = devCon.MapSubresource(buffer2, MapMode.WriteNoOverwrite, MapFlags.None);
			uint* ptr2 = (uint*)((void*)dataBox.Data.DataPointer);
			for (int j = 0; j < obj.IndexCount; j++)
			{
				uint value = ptr2[j];
				writer.Write(value);
			}
			devCon.UnmapSubresource(buffer2, 0);
			dataStream.Dispose();
			buffer2.Dispose();
			dataBox.Data.Dispose();
			list2.Add((int)writer.BaseStream.Position);
			writer.Write(45059);
			list.Add((int)writer.BaseStream.Position);
			writer.Write(0);
			writer.Write(obj.MaterialIDs.Count);
			foreach (int current in obj.MaterialIDs)
			{
				writer.Write(current);
			}
			list2.Add((int)writer.BaseStream.Position);
			writer.Write(45060);
			list.Add((int)writer.BaseStream.Position);
			writer.Write(0);
			writer.Write(obj.Subsets.Count);
			foreach (int current2 in obj.Subsets)
			{
				writer.Write(current2);
			}
			list2.Add((int)writer.BaseStream.Position);
			writer.Write(45062);
			list.Add((int)writer.BaseStream.Position);
			writer.Write(70);
			Object3D.WriteMatrix(writer, obj.Tranformation);
			list2.Add((int)writer.BaseStream.Position);
			for (int k = 1; k < list.Count; k++)
			{
				writer.Seek(list[k], SeekOrigin.Begin);
				writer.Write(list2[k - 1] - list[k] + 2);
			}
			writer.Seek(list[0], SeekOrigin.Begin);
			writer.Write(list2[list2.Count - 1] - list[0] + 2);
			writer.Seek(list2[list2.Count - 1], SeekOrigin.Begin);
		}

		public static void WriteMatrix(BinaryWriter writer, Matrix mat)
		{
			writer.Write(mat.M11);
			writer.Write(mat.M12);
			writer.Write(mat.M13);
			writer.Write(mat.M14);
			writer.Write(mat.M21);
			writer.Write(mat.M22);
			writer.Write(mat.M23);
			writer.Write(mat.M24);
			writer.Write(mat.M31);
			writer.Write(mat.M32);
			writer.Write(mat.M33);
			writer.Write(mat.M34);
			writer.Write(mat.M41);
			writer.Write(mat.M42);
			writer.Write(mat.M43);
			writer.Write(mat.M44);
		}

		public static void ReadMatrix(BinaryReader reader, ref Matrix mat)
		{
			mat.M11 = reader.ReadSingle();
			mat.M12 = reader.ReadSingle();
			mat.M13 = reader.ReadSingle();
			mat.M14 = reader.ReadSingle();
			mat.M21 = reader.ReadSingle();
			mat.M22 = reader.ReadSingle();
			mat.M23 = reader.ReadSingle();
			mat.M24 = reader.ReadSingle();
			mat.M31 = reader.ReadSingle();
			mat.M32 = reader.ReadSingle();
			mat.M33 = reader.ReadSingle();
			mat.M34 = reader.ReadSingle();
			mat.M41 = reader.ReadSingle();
			mat.M42 = reader.ReadSingle();
			mat.M43 = reader.ReadSingle();
			mat.M44 = reader.ReadSingle();
			bool flag = mat.M11 * mat.M12 * mat.M13 * mat.M14 == 0f;
			if (flag)
			{
				bool flag2 = mat.M21 * mat.M22 * mat.M23 * mat.M24 == 0f;
				if (flag2)
				{
					bool flag3 = mat.M31 * mat.M32 * mat.M33 * mat.M34 == 0f;
					if (flag3)
					{
						bool flag4 = mat.M41 * mat.M42 * mat.M43 == 0f;
						if (flag4)
						{
							mat = Matrix.Scaling(1f, 1f, 1f);
						}
					}
				}
			}
		}

		protected virtual void Dispose(bool disposing)
		{
			bool flag = !this.disposedValue;
			if (flag)
			{
				if (disposing)
				{
					SlimDX.Direct3D11.Buffer expr_1B = this.VertexBuffer;
					if (expr_1B != null)
					{
						expr_1B.Dispose();
					}
					SlimDX.Direct3D11.Buffer expr_2D = this.IndexBuffer;
					if (expr_2D != null)
					{
						expr_2D.Dispose();
					}
				}
				this.disposedValue = true;
			}
		}

		public void Dispose()
		{
			this.Dispose(true);
		}
	}
}
