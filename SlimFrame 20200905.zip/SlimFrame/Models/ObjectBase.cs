﻿using SlimDX;
using System;
using System.Collections.Generic;
using System.IO;

namespace SlimFrame.Models
{
	public class ObjectBase
	{
		public const ushort ObjectID = 45056;

		public const ushort VerticesID = 45057;

		public const ushort IndicesID = 45058;

		public const ushort MaterialID = 45059;

		public const ushort SubsetsID = 45060;

		public const ushort TransformationID = 45062;

		public const ushort SubsetNamesID = 45063;

		public Vertex[] vertices;

		public uint[] indices;

		public Matrix Tranformation;

		public List<int> meshSubsets;

		public List<string> SubsetNames;

		public List<int> MaterialIDs;

		public ObjectBase()
		{
			meshSubsets = new List<int>();
			MaterialIDs = new List<int>();
		}

		public void Write(BinaryWriter writer)
		{
			List<int> list = new List<int>();
			List<int> list2 = new List<int>();
			writer.Write(45056);
			list.Add((int)writer.BaseStream.Position);
			writer.Write(0);
			writer.Write(45057);
			list.Add((int)writer.BaseStream.Position);
			writer.Write(0);
			writer.Write(vertices.Length);
			Vertex[] array = vertices;
			for (int i = 0; i < array.Length; i++)
			{
				Vertex vertex = array[i];
				vertex.Write(writer);
			}
			list2.Add((int)writer.BaseStream.Position);
			writer.Write(45058);
			list.Add((int)writer.BaseStream.Position);
			writer.Write(0);
			writer.Write(indices.Length);
			uint[] array2 = indices;
			for (int j = 0; j < array2.Length; j++)
			{
				int value = (int)array2[j];
				writer.Write(value);
			}
			list2.Add((int)writer.BaseStream.Position);
			writer.Write(45059);
			list.Add((int)writer.BaseStream.Position);
			writer.Write(0);
			writer.Write(MaterialIDs.Count);
			foreach (int current in MaterialIDs)
			{
				writer.Write(current);
			}
			list2.Add((int)writer.BaseStream.Position);
			writer.Write(45060);
			list.Add((int)writer.BaseStream.Position);
			writer.Write(0);
			writer.Write(meshSubsets.Count);
			foreach (int current2 in meshSubsets)
			{
				writer.Write(current2);
			}
			writer.Write(45063);
			list.Add((int)writer.BaseStream.Position);
			writer.Write(0);
			foreach (string current3 in SubsetNames)
			{
				writer.Write(current3);
			}
			list2.Add((int)writer.BaseStream.Position);
			list2.Add((int)writer.BaseStream.Position);
			writer.Write(45062);
			list.Add((int)writer.BaseStream.Position);
			writer.Write(70);
			Object3D.WriteMatrix(writer, Tranformation);
			list2.Add((int)writer.BaseStream.Position);
			for (int k = 1; k < list.Count; k++)
			{
				writer.Seek(list[k], SeekOrigin.Begin);
				writer.Write(list2[k - 1] - list[k] + 2);
			}
			writer.Seek(list[0], SeekOrigin.Begin);
			writer.Write(list2[list2.Count - 1] - list[0] + 2);
			writer.Seek(list2[list2.Count - 1], SeekOrigin.Begin);
		}

		public void ApplySubsets(int[] subsets, MaterialBase[] materials)
		{
			for (int i = 0; i < subsets.Length; i++)
			{
				int num = subsets[i];
				bool flag = num == 0;
				if (!flag)
				{
					this.meshSubsets.Insert(1, num);
				}
			}
			for (int j = 0; j < materials.Length; j++)
			{
				MaterialBase materialBase = materials[j];
				this.MaterialIDs.Add(materialBase.ID);
			}
		}

		public void Read(BinaryReader reader, long ChunkEnding)
		{
			Chunk chunk = default(Chunk);
			while (true)
			{
				chunk.Read(reader);
				switch (chunk.id)
				{
					case 45057:
						{
							int num = reader.ReadInt32();
							vertices = new Vertex[num];
							for (int i = 0; i < num; i++)
							{
								vertices[i] = Vertex.Read(reader);
							}
							break;
						}
					case 45058:
						{
							int num2 = reader.ReadInt32();
							indices = new uint[num2];
							for (int j = 0; j < num2; j++)
							{
								indices[j] = reader.ReadUInt32();
							}
							break;
						}
					case 45059:
						{
							int num3 = reader.ReadInt32();
							for (int k = 0; k < num3; k++)
							{
								MaterialIDs.Add(reader.ReadInt32());
							}
							break;
						}
					case 45060:
						{
							int num4 = reader.ReadInt32();
							for (int l = 0; l < num4; l++)
							{
								meshSubsets.Add(reader.ReadInt32());
							}
							break;
						}
					case 45061:
						goto IL_13C;
					case 45062:
						Object3D.ReadMatrix(reader, ref Tranformation);
						break;
					default:
						goto IL_13C;
				}
				IL_152:
				if (reader.BaseStream.Position + 6L >= ChunkEnding)
				{
					break;
				}
				continue;
				IL_13C:
				reader.BaseStream.Seek(chunk.End, SeekOrigin.Begin);
				goto IL_152;
			}
			meshSubsets.Add(0);
			meshSubsets.Add(indices.Length);
		}

		public void Clear()
		{
			vertices = null;
			indices = null;
			Tranformation = Matrix.Identity;
			MaterialIDs.Clear();
			meshSubsets.Clear();
			SubsetNames.Clear();
		}
	}
}
